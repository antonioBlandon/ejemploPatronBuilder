package co.com.bancolombia.certificacion.googletranslatescreenplay.stepdefinitions;

import co.com.bancolombia.certificacion.googletranslatescreenplay.questions.TheWord;
import co.com.bancolombia.certificacion.googletranslatescreenplay.tasks.OpenTheBrowser;
import co.com.bancolombia.certificacion.googletranslatescreenplay.tasks.Translated;
import co.com.bancolombia.certificacion.googletranslatescreenplay.userinterface.HomePage;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.abilities.BrowseTheWeb;
import net.thucydides.core.annotations.Managed;
import org.openqa.selenium.WebDriver;

import static net.serenitybdd.screenplay.GivenWhenThen.seeThat;
import static org.hamcrest.core.Is.is;


public class TranslateStepDefinition{

    @Managed(driver = "chrome")
    private WebDriver herBrowser;

    private Actor fren = Actor.named("fren");

    private HomePage homePage;

    @Before
    public void setUp(){
        fren.can(BrowseTheWeb.with(herBrowser));
    }

    @Given("^that Jose wants to translates to word$")
    public void thatJoseWantsToTranslatesToWord() {
        fren.wasAbleTo(OpenTheBrowser.on(homePage));
    }


    @When("^he translates (.*) fron english to italian$")
    public void heTranslatesCheeseFronEnglishToItalian(String word) {
        fren.wasAbleTo(Translated.the(word));
    }

    @Then("^he should see that the new word is (.*)$")
    public void heShouldSeeThatTheNewWordIsFormaggio(String wordTranslated) {
        fren.should(seeThat(TheWord.translated(), is(wordTranslated)));
    }
}
