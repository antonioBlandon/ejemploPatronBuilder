package co.com.bancolombia.certificacion.googletranslatescreenplay.tasks;

import co.com.bancolombia.certificacion.googletranslatescreenplay.interactions.Select;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.actions.Enter;

import static co.com.bancolombia.certificacion.googletranslatescreenplay.userinterface.HomePage.*;
import static net.serenitybdd.screenplay.Tasks.instrumented;

public class Translated implements Task {

    private String word;

    public Translated(String word) {
        this.word = word;
    }

    public static Translated the(String word) {
        //return new Translated(word);
        return instrumented(Translated.class, word);
    }

    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(Select.language()
                ,Enter.theValue(word).into(TEXT_AREA_SOURCE));
    }
}
