package co.com.bancolombia.certificacion.googletranslatescreenplay.userinterface;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.screenplay.targets.Target;
import net.thucydides.core.annotations.DefaultUrl;
import org.openqa.selenium.By;

@DefaultUrl("https://translate.google.com/?hl=es")
public class HomePage extends PageObject {
    public static Target SELECT_LANGUAGE_SOURCE = Target
            .the("select language source")
            .locatedBy("//div[@class='sl-more tlid-open-source-language-list']");
    public static Target SELECT_LANGUAGE_TARGET = Target
            .the("select language target")
            .locatedBy("//div[@class='tl-more tlid-open-target-language-list']");
    public static Target LANGUAGE_SOURCE = Target
            .the("language source")
            .locatedBy("/html/body/div[2]/div[3]/div/div[2]/div[1]/div[2]/div/div[3]/div[50]/div[2]");
    public static Target LANGUAGE_TARGET = Target
            .the("language target")
            .locatedBy("/html/body/div[2]/div[3]/div/div[2]/div[2]/div[2]/div/div[2]/div[54]");
    public static Target TEXT_AREA_SOURCE = Target.the("text area source")
            .located(By.id("source"));
    public static Target TEXT_AREA_TARGET = Target
            .the("text area target")
            .locatedBy("//span[@class='tlid-translation translation']");
}
