package co.com.bancolombia.certificacion.googletranslatescreenplay.interactions;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Interaction;
import net.serenitybdd.screenplay.actions.Click;

import static co.com.bancolombia.certificacion.googletranslatescreenplay.userinterface.HomePage.*;

public class Select implements Interaction {
    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(Click.on(SELECT_LANGUAGE_SOURCE)
                ,Click.on(LANGUAGE_SOURCE)
                ,Click.on(SELECT_LANGUAGE_TARGET)
                ,Click.on(LANGUAGE_TARGET));
    }

    public static Select language() {
        return new Select();
    }
}
