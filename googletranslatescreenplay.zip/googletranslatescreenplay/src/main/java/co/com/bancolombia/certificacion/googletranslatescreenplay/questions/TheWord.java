package co.com.bancolombia.certificacion.googletranslatescreenplay.questions;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;

import static co.com.bancolombia.certificacion.googletranslatescreenplay.userinterface.HomePage.TEXT_AREA_TARGET;

public class TheWord implements Question<String>{
    public static TheWord translated(){
        return new TheWord();
    }

    @Override
    public String answeredBy(Actor actor) {
        return TEXT_AREA_TARGET.resolveFor(actor).getText();
    }
}
